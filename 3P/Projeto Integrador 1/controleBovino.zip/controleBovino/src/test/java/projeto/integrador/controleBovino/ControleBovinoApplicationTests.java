package projeto.integrador.controleBovino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleBovinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
